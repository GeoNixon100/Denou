<?php

namespace database;

use pocketmine\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

class main extends PluginBase implements Listener{
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this,$this);
        $this->getLogger()->info("Плагин успешно запущен!");
        return true;
    }
    public function onJoin(PlayerJoinEvent $event){
        $player=$event->getPlayer();
        $nick=$player->getName();
        $event->setJoinMessage("§eИгрок {$nick} зашел к нам!");
        $player->sendMessage("§aДобро пожаловать, {$nick}!");
        return true;
    }
    public function onQuit(PlayerQuitEvent $event){
        $player=$event->getPlayer();
        $nick=$player->getName();
        $event->setQuitMessage("§eИгрок {$nick} покинул наш сервер!");
        return true;
    }
}

?>